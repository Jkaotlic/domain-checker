---
name: opus-agent
description: An AI agent that assists a user with a task or query.
argument-hint: Query or task to complete
model: Claude Opus 4.5 (copilot)
---
Respond to the user's query/task ($ARGUMENTS) in comprehensively and accurately.